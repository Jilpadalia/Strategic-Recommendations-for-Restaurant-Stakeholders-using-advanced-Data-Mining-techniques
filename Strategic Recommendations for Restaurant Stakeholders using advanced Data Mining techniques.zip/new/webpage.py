import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pyfpgrowth
import seaborn as sns
from sklearn.cluster import DBSCAN
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from prefixspan import PrefixSpan

def eda():
    file_path = 'zomato.csv'  # Replace 'your_dataset.csv' with the path to your CSV file
    df = pd.read_csv(file_path)

    # Drop rows with missing values in 'approx_cost(for two people)' and 'rate' columns
    df = df.dropna()

    # Filter out rows where 'rate' is "NEW" or "-"
    df = df[(df['rate'] != 'NEW') & (df['rate'] != '-')]

    # Convert 'approx_cost(for two people)' column to numeric
    df['approx_cost(for two people)'] = df['approx_cost(for two people)'].str.replace(',', '').astype(float)

    # Remove rows with 'approx_cost(for two people)' greater than 4000
    df = df[df['approx_cost(for two people)'] <= 2000]

    # Extract numeric part of 'rate' column before the backslash
    df['rate'] = df['rate'].str.split('/').str[0].astype(float)
    
        # Assuming df is your DataFrame
    sns.boxplot(x=df['rate'], data=df)
    plt.title('Boxplot of Ratings')
    plt.xlabel('Rating')
    plt.savefig('eda1.png')
    st.image('eda1.png')
    
    sns.boxplot(x=df['approx_cost(for two people)'], data=df)
    plt.title('Boxplot of cost')
    plt.xlabel('Approx_cost')
    plt.savefig('eda2.png')
    st.image('eda2.png')
    
        # Get the counts of each unique value
    value_counts = df['listed_in(type)'].value_counts()

    # Plot the bar graph
    plt.figure(figsize=(10, 6))
    value_counts.plot(kind='bar', color='skyblue')

    # Add labels and title
    plt.title('Restaurant types in bangalore')
    # plt.xlabel('Unique Values')
    plt.ylabel('Restaurants')

    # Add value labels on top of each bar
    for i, count in enumerate(value_counts):
        plt.text(i, count + 0.1, str(count), ha='center', va='bottom')

    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    # plt.show()
    plt.savefig('eda3.png')
    st.image('eda3.png')
   
def loc():
    file_path = 'zomato.csv'  
    df = pd.read_csv(file_path)
    df = df.dropna()
    # Get unique locations from the DataFrame
    locations = [''] + list(df['location'].unique())
    
    df = df[(df['rate'] != 'NEW') & (df['rate'] != '-')]
    df['rate'] = df['rate'].str.split('/').str[0].astype(float)
     # Convert 'rate' column to numeric
    # df['rate'] = df['rate'].apply(lambda x: float(x.split('/')[0]) if isinstance(x, str) else x)

    # Standardize the data
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df[['rate', 'votes']])

    # Apply PCA
    pca = PCA(n_components=1)
    principal_components = pca.fit_transform(scaled_data)

    # # Add PCA result as a new column to the DataFrame
    df['pca_component'] = principal_components

    # Streamlit app
    st.title('Location Selection')
    selected_location = st.selectbox('Select Location', locations)

    # Display selected location
    st.write('You selected:', selected_location)

    # Filter restaurants based on selected location
    filtered_restaurants = df[df['location'] == selected_location]

    # Sort restaurants by rating in decreasing order
    sorted_restaurants = filtered_restaurants.sort_values(by='pca_component', ascending=False)

    # Retrieve top 10 restaurants
    top_10_restaurants = sorted_restaurants.head(10)
    st.subheader('Top 10 Restaurants in {}'.format(selected_location))
    for row in top_10_restaurants.iterrows():
        st.markdown('Name: {} '.format(row['name']))
        st.markdown('URL: {}'.format(row['url'])) 
    # Display only name and URL of filtered restaurants
    
def fpgrowth():

    file_path = 'zomato.csv'  
    df = pd.read_csv(file_path)
    df = df.dropna()
    
    st.write('Select Minimum Support:')
    user_input = st.number_input("Enter an integer:", step=1, value=50, format="%d")
    # Convert the 'rest_type' column to a list of lists
    transactions = df['rest_type'].apply(lambda x: x.split(',')).tolist()

    # Perform FP-growth algorithm to find frequent itemsets
    patterns = pyfpgrowth.find_frequent_patterns(transactions, user_input)  # Adjust the support threshold as needed

    # Print the frequent itemsets
    for itemset, support in patterns.items():
        st.write(f"Itemset: {itemset}, Support: {support}")

def scatter():
    file_path = 'zomato.csv'  # Replace 'your_dataset.csv' with the path to your CSV file
    df = pd.read_csv(file_path)

    # Drop rows with missing values in 'approx_cost(for two people)' and 'rate' columns
    df = df.dropna()

    # Filter out rows where 'rate' is "NEW" or "-"
    df = df[(df['rate'] != 'NEW') & (df['rate'] != '-')]

    # Convert 'approx_cost(for two people)' column to numeric
    df['approx_cost(for two people)'] = df['approx_cost(for two people)'].str.replace(',', '').astype(float)

    # Remove rows with 'approx_cost(for two people)' greater than 4000
    df = df[df['approx_cost(for two people)'] <= 2000]

    # Extract numeric part of 'rate' column before the backslash
    df['rate'] = df['rate'].str.split('/').str[0].astype(float)

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.scatter(df['approx_cost(for two people)'], df['rate'], alpha=0.5)
    plt.title('Rating vs Approx Cost for Two People')
    plt.xlabel('Approx Cost (for two people)')
    plt.ylabel('Rating')
    # plt.grid(True)

    # Set custom x-axis ticks
    x_ticks = np.arange(0, 2001, 500)
    plt.xticks(x_ticks)
    plt.savefig('img.png')
    st.image('img.png')
    # Show the plot
    # plt.show()
    
def kmeans():
    file_path = 'zomato.csv'  # Replace 'your_dataset.csv' with the path to your CSV file
    df = pd.read_csv(file_path)

    # Drop rows with missing values in 'approx_cost(for two people)' and 'rate' columns
    df = df.dropna()

    # Filter out rows where 'rate' is "NEW" or "-"
    df = df[(df['rate'] != 'NEW') & (df['rate'] != '-')]

    # Convert 'approx_cost(for two people)' column to numeric
    df['approx_cost(for two people)'] = df['approx_cost(for two people)'].str.replace(',', '').astype(float)

    # Remove rows with 'approx_cost(for two people)' greater than 4000
    df = df[df['approx_cost(for two people)'] <= 2000]

    # Extract numeric part of 'rate' column before the backslash
    df['rate'] = df['rate'].str.split('/').str[0].astype(float)
    
    X = df[['approx_cost(for two people)', 'rate']].values
    kmeans = KMeans(n_clusters=5, random_state=42)
    kmeans.fit(X)
    centroids = kmeans.cluster_centers_
    labels = kmeans.labels_

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.scatter(df['approx_cost(for two people)'], df['rate'], c=labels, cmap='viridis', alpha=0.5)
    plt.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='x', s=100, label='Centroids')
    plt.title('Rating vs Approx Cost for Two People (with Clusters)')
    plt.xlabel('Approx Cost (for two people)')
    plt.ylabel('Rating')
    # plt.grid(True)
    plt.legend()
    plt.savefig('kmeans.png')
    st.image('kmeans.png')
    # plt.show()
       
def dbscan():
    file_path = 'zomato.csv'  # Replace 'your_dataset.csv' with the path to your CSV file
    df = pd.read_csv(file_path)

    # Drop rows with missing values in 'approx_cost(for two people)' and 'rate' columns
    df = df.dropna()

    # Filter out rows where 'rate' is "NEW" or "-"
    df = df[(df['rate'] != 'NEW') & (df['rate'] != '-')]

    # Convert 'approx_cost(for two people)' column to numeric
    df['approx_cost(for two people)'] = df['approx_cost(for two people)'].str.replace(',', '').astype(float)

    # Remove rows with 'approx_cost(for two people)' greater than 4000
    df = df[df['approx_cost(for two people)'] <= 2000]

    # Extract numeric part of 'rate' column before the backslash
    df['rate'] = df['rate'].str.split('/').str[0].astype(float)
    # Perform DBSCAN clustering
    X = df[['approx_cost(for two people)', 'rate']].values
    X = StandardScaler().fit_transform(X)  # Standardize features by removing the mean and scaling to unit variance
    dbscan = DBSCAN(eps=0.3, min_samples=10)
    labels = dbscan.fit_predict(X)

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.scatter(df['approx_cost(for two people)'], df['rate'], c=labels, cmap='viridis', alpha=0.5)
    plt.title('Rating vs Approx Cost for Two People (with Clusters)')
    plt.xlabel('Approx Cost (for two people)')
    plt.ylabel('Rating')
    plt.savefig('dbscan.png')
    st.image('dbscan.png')
    # plt.grid(True)
    # plt.show()
    
def gmm():
    file_path = 'zomato.csv'  # Replace 'your_dataset.csv' with the path to your CSV file
    df = pd.read_csv(file_path)

    # Drop rows with missing values in 'approx_cost(for two people)' and 'rate' columns
    df = df.dropna()

    # Filter out rows where 'rate' is "NEW" or "-"
    df = df[(df['rate'] != 'NEW') & (df['rate'] != '-')]

    # Convert 'approx_cost(for two people)' column to numeric
    df['approx_cost(for two people)'] = df['approx_cost(for two people)'].str.replace(',', '').astype(float)

    # Remove rows with 'approx_cost(for two people)' greater than 4000
    df = df[df['approx_cost(for two people)'] <= 2000]

    # Extract numeric part of 'rate' column before the backslash
    df['rate'] = df['rate'].str.split('/').str[0].astype(float)
    
        # Perform Gaussian Mixture Model (GMM) clustering
    X = df[['approx_cost(for two people)', 'rate']].values
    X = StandardScaler().fit_transform(X)  # Standardize features by removing the mean and scaling to unit variance
    gmm = GaussianMixture(n_components=5, random_state=42)
    labels = gmm.fit_predict(X)

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.scatter(df['approx_cost(for two people)'], df['rate'], c=labels, cmap='viridis', alpha=0.5)
    plt.title('Rating vs Approx Cost for Two People (with Clusters)')
    plt.xlabel('Approx Cost (for two people)')
    plt.ylabel('Rating')
    # plt.grid(True)
    plt.savefig('gmm.png')
    st.image('gmm.png')
    # plt.show()
                
def main():
    
    if(st.button('EDA')):
        eda()

    if(st.button('FPgrowth Algo')):
        fpgrowth() 
        
    if(st.button('Scatter')):
        st.title('Scatter plot Distribution')
        scatter()
        
    if(st.button('Kmeans')):
        st.title('Kmeans Clustering')
        kmeans()  
        
    if(st.button('DBSCAN')):
        st.title('Dbscan CLustering')
        dbscan()
    
    if(st.button('GMM')):
        st.title('Gaussian mixture model')
        gmm()
    
    if st.button('Location based retrieval system'):
        loc()
        
           
if __name__=="__main__": 
    main() 